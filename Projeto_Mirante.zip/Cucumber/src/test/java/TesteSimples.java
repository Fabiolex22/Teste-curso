import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TesteSimples {
    public static void main(String[] args) {
        WebDriverManager.chromedriver().setup();  // Aqui baixa a versão correta automaticamente
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.google.com");
        // ...
        driver.quit();
    }
}
