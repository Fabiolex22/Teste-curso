package br.fabiolex.Steps;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import br.fabiolex.pages.MirantePage;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.pt.Dado;
import io.cucumber.java.pt.Quando;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Mirante_teste_Steps {

    private WebDriver driver;
    private MirantePage mirantePage;  

    @Before
    public void iniciarTeste() {
        WebDriverManager.chromedriver().driverVersion("137.0.7151.70").setup();

        ChromeOptions options = new ChromeOptions();
        options.setBinary("C:\\Users\\fabio\\Downloads\\chrome-win64\\chrome-win64\\chrome.exe");

        driver = new ChromeDriver(options);
        driver.manage().window().maximize();

        mirantePage = new MirantePage(driver); 
    }

    @After
    public void finalizarTeste() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Dado("que acesso o site da Mirante")
    public void que_acesso_o_siteda_Mirante() {
        driver.get("https://www.mirante.net.br/");
        mirantePage.esperar(2000);
    }

    @Quando("passo o mouse sobre o menu Carreira")
    public void passo_o_mouse_sobre_o_menu_Carreira() {
    	mirantePage.hoverMenuCarreira();
        mirantePage.esperar(1000);
    }
    @Quando("clico na palavra {string}")
    public void clico_no_menu(String string) {
    	mirantePage.esperar(1000);
    	
       
    }
    @Quando("clico na vaga {string}")
	public void clicarN_aAcao(String string) {
    	mirantePage.esperar(2000);
    	
		
	}
}
