package br.fabiolex.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

public class MirantePage {

    private WebDriver driver;

    private By menuCarreira = By.id("menu-item-18");
    private By buscarVagas = By.xpath("//a[contains(text(),'Buscar vagas')]");

    public MirantePage(WebDriver driver) {
        this.driver = driver;
    }

  
    public void hoverMenuCarreira() {
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(menuCarreira)).perform();
    }

    
   
    public void clicarBuscarVagas() {
        driver.findElement(buscarVagas).click();
    }
    

    /**
     * Pausa a execução por uma quantidade de milissegundos
     * @param tempoMs tempo em milissegundos
     */
    public void esperar(long tempoMs) {
        try {
            Thread.sleep(tempoMs);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

